package liste_skjelett;

class Kø <E> extends Lenkeliste<E> {
    // oppfører seg likt som lenkeliste
}

