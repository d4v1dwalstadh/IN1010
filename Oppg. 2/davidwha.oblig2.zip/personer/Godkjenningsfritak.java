package personer;

public interface Godkjenningsfritak {
    String hentKontrollkode();
}
